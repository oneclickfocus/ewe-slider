<?php
$settings = $this->get_settings_for_display();
$elementClass = 'effectHover';
if ($settings['hover_image_animation']) {
    $elementClass .= ' elementor-animation-' . $settings['hover_image_animation'];
}
$this->add_render_attribute('wrapper-img', 'class', $elementClass);
$wrapperImg = $this->get_render_attribute_string('wrapper-img');

?>
<!-- Swiper -->
<div class="swiper w-100 h-100 d-grid mySwiper ewe-slider-icon-color" style="fill:<?php echo esc_attr($settings['icon_color']); ?>; ">
    <div class="swiper-wrapper">
        <?php
        foreach ($settings['list'] as $slider) {
            $slider['slider_description'] = substr($slider['slider_description'], 0, 140) . '...';


            $image = wp_get_attachment_image($slider['slider_image']['id'], $slider['thumbnail_size'], '', array('class' => 'ewe-slider-image'));
            echo '<div class="swiper-slide text-center d-block ewe-slider-container"> <div ' . $wrapperImg . ' >'
                . $image . '</div><h3 class="ewe-slider-title text-start">' . $slider['slider_name'] . '</h3> <p class="ewe-slider-profession text-start">' .
                $slider['slider_profession'] . '</p>';
            echo '<div class="ewe-slider-description text-start">' . $slider['slider_description'] . '</div> <div class="container-social-media d-flex justify-content-start position-absolute">';

            if ($slider['facebook_link']['url']) {
                echo '<a class="ewe-slider-icon-color-bg" href="' . $slider['facebook_link']['url'] . '" target="_blank"><svg style="width: 16px; height: 16px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><!--! Font Awesome Pro 6.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z" class="ewe-slider-icon-color"/></svg></a>';
            }
            if ($slider['twitter_link']['url']) {
                echo '<a class="ewe-slider-icon-color-bg" href="' . $slider['twitter_link']['url'] . '" target="_blank"><svg style="width: 16px; height: 16px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z" class="ewe-slider-icon-color"/></svg></a>';
            }
            if ($slider['linkedin_link']['url']) {
                echo '<a class="ewe-slider-icon-color-bg" href="' . $slider['linkedin_link']['url'] . '" target="_blank"><svg style="width: 16px; height: 16px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z" class="ewe-slider-icon-color"/></svg></a>';
            }
            if ($slider['pinterest_link']['url']) {
                echo '<a class="ewe-slider-icon-color-bg" href="' . $slider['pinterest_link']['url'] . '" target="_blank"><svg style="width: 16px; height: 16px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--! Font Awesome Pro 6.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M204 6.5C101.4 6.5 0 74.9 0 185.6 0 256 39.6 296 63.6 296c9.9 0 15.6-27.6 15.6-35.4 0-9.3-23.7-29.1-23.7-67.8 0-80.4 61.2-137.4 140.4-137.4 68.1 0 118.5 38.7 118.5 109.8 0 53.1-21.3 152.7-90.3 152.7-24.9 0-46.2-18-46.2-43.8 0-37.8 26.4-74.4 26.4-113.4 0-66.2-93.9-54.2-93.9 25.8 0 16.8 2.1 35.4 9.6 50.7-13.8 59.4-42 147.9-42 209.1 0 18.9 2.7 37.5 4.5 56.4 3.4 3.8 1.7 3.4 6.9 1.5 50.4-69 48.6-82.5 71.4-172.8 12.3 23.4 44.1 36 69.3 36 106.2 0 153.9-103.5 153.9-196.8C384 71.3 298.2 6.5 204 6.5z" class="ewe-slider-icon-color" /></svg></a>';
            }
            if ($slider['instagram_link']['url']) {
                echo '<a class="ewe-slider-icon-color-bg" href="' . $slider['instagram_link']['url'] . '" target="_blank"><svg style="width: 16px; height: 16px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z" class="ewe-slider-icon-color" /></svg></a>';
            }
            echo '</div>';
            if ($slider['email_link']['url']) {
                echo '<div style="float:right; padding-right: 20px;" ><a class="ewe-slider-icon-color-bg" href="mailto:' . $slider['email_link']['url'] . '" target="_blank"><svg style="width: 16px; height: 16px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M256 352c-16.53 0-33.06-5.422-47.16-16.41L0 173.2V400C0 426.5 21.49 448 48 448h416c26.51 0 48-21.49 48-48V173.2l-208.8 162.5C289.1 346.6 272.5 352 256 352zM16.29 145.3l212.2 165.1c16.19 12.6 38.87 12.6 55.06 0l212.2-165.1C505.1 137.3 512 125 512 112C512 85.49 490.5 64 464 64h-416C21.49 64 0 85.49 0 112C0 125 6.01 137.3 16.29 145.3z" class="ewe-slider-icon-color"/></svg></a></div>';
            }
            if ($slider['telephone_link']['url']) {
                echo '<div style="float:right;"><a class="ewe-slider-icon-color-bg" style="margin-right: 5px;" href="tel:' . $slider['telephone_link']['url'] . '" target="_blank"> <svg style="width: 16px; height: 16px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.0.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path d="M18.92 351.2l108.5-46.52c12.78-5.531 27.77-1.801 36.45 8.98l44.09 53.82c69.25-34 125.5-90.31 159.5-159.5l-53.81-44.04c-10.75-8.781-14.41-23.69-8.974-36.47l46.51-108.5c6.094-13.91 21.1-21.52 35.79-18.11l100.8 23.25c14.25 3.25 24.22 15.8 24.22 30.46c0 252.3-205.2 457.5-457.5 457.5c-14.67 0-27.18-9.968-30.45-24.22l-23.25-100.8C-2.571 372.4 5.018 357.2 18.92 351.2z" class="ewe-slider-icon-color"/></svg></a></div>';
            }

            echo '</div>';
        };

        ?>
    </div>
    <div>
        <div class="swiper-pagination"></div>
    </div>

</div>

<div class="swiper-button-next">
    <div class="icon-navigation-wrapper">
        <?php \Elementor\Icons_Manager::render_icon($settings['icon_navigation_next'], ['aria-hidden' => 'true']); ?>
    </div>
</div>
<div class="swiper-button-prev">
    <div class="icon-navigation-wrapper">
        <?php \Elementor\Icons_Manager::render_icon($settings['icon_navigation_prev'], ['aria-hidden' => 'true']); ?>
    </div>
</div>

<!-- Initialize Swiper -->
<script>
    var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 30,
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {

            740: {
                slidesPerView: 2,
            },
            1100: {
                slidesPerView: 3,
            }
        }
    });
</script>
<?php
