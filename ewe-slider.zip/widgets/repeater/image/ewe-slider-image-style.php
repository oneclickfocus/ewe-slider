<?php 
    // $this->add_control(
    //     'image_style',
    //     [
    //         'label' => esc_html__( 'Imagen', 'elementor-ewe-slider' ),
    //         'type' => \Elementor\Controls_Manager::HEADING,
    //         'separator' => 'before',
    //     ]
    // );

    // $this->add_control(
    //     'hover_image_animation',
    //     [
    //         'label' => esc_html__( 'Animación hover', 'elementor-ewe-slider' ),
    //         'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
    //     ]
    // );

?>